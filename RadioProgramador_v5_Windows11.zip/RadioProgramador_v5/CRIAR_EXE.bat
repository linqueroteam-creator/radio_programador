@echo off
chcp 65001 > nul
color 0A
echo.
echo  ============================================================
echo    RADIO PROGRAMADOR v5.0 — Compilador do Instalador
echo  ============================================================
echo.
echo  Este script cria o RadioProgramador_Setup.exe
echo  (arquivo unico de instalacao)
echo.

:: Verifica Python
python --version > nul 2>&1
if errorlevel 1 (
    echo  [ERRO] Python nao encontrado no PATH.
    echo  Instale Python 3.10+ em python.org
    pause
    exit /b 1
)

python -c "import sys; print(f'  Python {sys.version_info.major}.{sys.version_info.minor} encontrado.')"
echo.

:: Instala PyInstaller
echo  [1/3] Instalando PyInstaller...
python -m pip install pyinstaller --upgrade --quiet
if errorlevel 1 (
    echo  [ERRO] Falha ao instalar PyInstaller.
    pause
    exit /b 1
)
echo  PyInstaller pronto.
echo.

:: Compila o instalador
echo  [2/3] Compilando RadioProgramador_Setup.exe...
echo  (pode levar 1-3 minutos na primeira vez)
echo.

pyinstaller --onefile --windowed ^
    --name "RadioProgramador_Setup" ^
    --distpath ".\dist" ^
    --workpath ".\build_tmp" ^
    --specpath ".\build_tmp" ^
    instalador.py

if errorlevel 1 (
    echo.
    echo  [ERRO] Compilacao falhou. Verifique os erros acima.
    pause
    exit /b 1
)

echo.
echo  [3/3] Limpando arquivos temporarios...
if exist "build_tmp" rmdir /s /q "build_tmp"
if exist "RadioProgramador_Setup.spec" del "RadioProgramador_Setup.spec"

echo.
echo  ============================================================
echo    CONCLUIDO!
echo.
echo    Arquivo gerado: dist\RadioProgramador_Setup.exe
echo.
echo    Distribua APENAS esse arquivo .exe
echo    O usuario clica duas vezes e instala tudo sozinho.
echo  ============================================================
echo.

:: Abre a pasta dist
explorer dist

pause
