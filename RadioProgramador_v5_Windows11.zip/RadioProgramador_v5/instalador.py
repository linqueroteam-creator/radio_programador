"""
Rádio Programador v5.0 — Instalador
Compilar com: pyinstaller --onefile --windowed --name RadioProgramador_Setup instalador.py
"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading, subprocess, sys, os, platform, base64, zlib, webbrowser, winreg
import urllib.request, urllib.error

SISTEMA = platform.system()
PYTHON  = sys.executable
VERSAO  = "5.0"

# Programa principal embutido (comprimido + base64)
_PROG_B64 = (
    "eNrlvWtz3EiWGPqdvwKNdpuoFlSqKj5EoaemXSIpiV6JpEmqtbMUbwWqgCLRRAHVAIqP5tAxjhux"
    "vuEIh713J+y4ex1xd9YRd+I6PB/8wfeLP+qf6Bf4J/ick5lAJpCoh6SeHs2y2WIVkM+TJ887T5qm"
    "udL9iJ8Vwzjq7ewdGIdHB8+Peq96OwdHxtVGswUvnvlJ4o79KHMNzzd6Uy/I4iRwjTfBw2eB8f43"
    "v4VPkRdfp0a7/XGDMGEWK8F4EieZkV0GUeYnhpvCx5VREo/zR6JEdmkbYz9N3XN/EN/YRjpM4jD0"
    "vcy/yWxjFMDHwA3jc3gDVcQ30cGFm16EwcA2Lsbu0DbiFIplyXQIVbOLxHe9IIKaWTD24cV0MEni"
    "IfQlak9CNxvFydg2Enx/i7Xj4aUPtb9P44gN2HMzHxsQIxbfRSOJC3CDJqZJCCNpJv4PUz/N8u8A"
    "9zhZWTneOz7ZfdUzunmnTegv88dWY+W73aPj3oEB70xYLHPl8FcnLw728TsUafo3/nCauYPQX1n5"
    "0nj/29/Ar7EdJ37Kv/yp/a5sw8jvAOcMwxxNATimY9CXL1teu91+bNrSuw57aX7Z3mwPOh3l3Vr+"
    "bthpd7bEu4kbRH4o3sGbzY4n3l35iefn/a098dY21pR3fS8Yw3uot7a1ubYpvRv74QUN1fxytLXR"
    "Xn8i3rljN/FDNgvzS39tsLbezt/9OOUjwXcbW+7maCTeJfFNXLwbDLeGxbth4EYFXB4/GbaKd4j5"
    "xbtRa7Q5Girv8jlsDZ6sP/HFu0GceG4x99ba5loOl9AFNP3e5XMYjR4POji/ewml3kD1MEizPzms"
    "WnlzcLTzEvYPoNUpm067s7a+sfkYUCL/+ET+3IIvEzdNr2FO8NH1xkEELwU0frj2k+y2DdiWf4R3"
    "JhGmyM/g43UASw6Ugj6OAmxYVBbfN+AdNHvhDt3Uhc+pD59ZweLzxiZ2Pxh6cgtYodPqYEH+cYPq"
    "nE9hkYbY1sgdB2HgsmG54ziRq3/vp9OUvfJ8+oQtDRI3DUL2eDTNgJiGbfwYItU/j9vF7gnHfgCF"
    "sXdgAVF2AbiI31I3nrjTEIvC5yiLeSdXbjqMlfEn0x+hCSroZiFQwyF9Pk/8cRBLsBRDizN3FEtj"
    "gOfjqecmCEH8y6pkQJzFZzeE6vAFPkYxDADhKWoT0BMf9jlfAFwRvlCez1cD3w9iDkFYU3yc938V"
    "XMViCYewNfjsTCDr+aLFAccmVp8X59QpAGjzOudXWV4nnfi+x5HpCkjGjQAAsAhXhqBASHyZxHGW"
    "45ObMrDB52nKAIjPz5GlyA1k8N0Xo/bHE1EQkV58BjaZd+Ii24ulLQA0LRBT+D5OfVHp+9jNQeNG"
    "BQ5PfC9RkCCcAkgFDNxBEvghbagxsEeBnok7cn2Bk34YTHxpBEnsJQEgRYdeJhGyUcIowLwoYM8B"
    "H0KBhp4bBbwxjkWtTmuttY57vd3udNbW1tc5DeDDavMf+NjhP6LuGv+BV+v8Bz5u8B/4uMl/4ONj"
    "/iPqbvEfePWE/8DHFv/Bftc2HnfWN7EA/sGvou6TrcebG+trODf+CUfXKlANx8sGCjNh/4m6qTtO"
    "p9E5VggmF3Hk860SwcoEXpt2AIlw+DEMoumNvF7ncXwe8iojQIdBHF9SU1GauecgG2L9CzdL3cmk"
    "zXB+FAY3+Z4JwvjKv42niObTKL0AHkz0BbB34IZEa4DO5agDJM8fnV/kiw3bUbwTtJX3cu6zfQ4j"
    "vgR5Bz9mE/xSzNxjXxkmM+JHLSXxlLYLol3s+eMcHTP/2r3Nh07UgxNc8XmDUxb+GGkH/3gRj31l"
    "tx+6/+SfXLeIkRxzug4fezlPMa/9cIiVcJv8M2A6VJZ3PZ34yYWfxNh15ibXbkIzhLr+ELZHRiBM"
    "sijIWP340h/HUTH1yE2mGaepIPqOYXdQwXia5Pt0kriZ2MsoXQYRkbqzFeTuHyXLf2lsv9jd7j3f"
    "fWXs7MLv4e7+zu7+9l7v+GNbXgH0MPoo/4KQ3HBoslygZn9Qdp5mQUhvEj+bJlHpTXME6N4Hmjuk"
    "NowgNaI4M/ZhZ6yw9oO0T5TWEh2MjFwOB2Gbazwme4k/WXJbfJGGNMxuJ36qvOFDYm+auPPCsJle"
    "+GG41mnupa+BeveiHuvd+KJrtPLa/s3Qn2TGLv0J4sjRtfvMDVNfnnucNs99IK2BB+11sT02RwBh"
    "P5oM3Ylmkl9oJ8kbPEmmrAPAP2NiBJFxmpjbzlte4e0xqSdrnbf72DrHR3mgpcJvDt5srs8sfJjE"
    "SGiMZ6DUpbzkWTEuGDhMcuJmF80g9YLEmjS0oMkHrqwWXylYiMQ/z5+yr82DiR/9hX9r8a8v/mL3"
    "V/2XB9u9l/1Xve0Xe/u7oAGaxwfPTt70jnb5yBq1AKtfQGXx2PqgSO0mgIfuBGhVWqwSsmSUaM8+"
    "EDWB9qGGmCu1zWQaWWW4G6dIYtMLpFKhGyEVuoivhXxGYzDPKqtlwPxhIn4f+phMsy7OHLRo0D3Y"
    "x0p5PxrGqGp3zWk2egiMzyC1N+2awXkEqqrJdHBorttuKbUbzTTz4LnyEDFyjBiZ+LTJgTgmVmLu"
    "A5F9m37twP9W80EDGoWKqLs3957vHxwBoTreLaEM/lwBmMbNc2AWE6uN/SUBbJZKMViBq2rlYq2a"
    "wBj9yLOuGgvuZJTFxNoiYWLNyPguUMAkKwzMBz4w3mjs+xkoL5eg6EfAKbBx80whhVT5U1D43svn"
    "B0d7J68Ojo03h72OYW21Os12O2h8EhI/GV9axHNtI00Djy8PnwS33jQng0tv1OmjDccCBEXuZVCl"
    "JiGWbzVYbenreuvJpm2sdRq8m2S00e5Yl7YRDkLbyPuxjQgAPDChQYZ31xdAfIzQj6ykYfzC2Fwv"
    "1mOcnkNZqJ93YzyAqm9vQKiDTx78z2xLQKOGl5b5FBqNJCphGA+6ZIdqRv41DgUatPM54rQaTS84"
    "B8ldwr6IarVlqCSnzub6GZ9XdmkBCPuX/i205w777oT9HYaBbbgRwCXic4WniEzIcHhBXq7xYOze"
    "lJ9RlSg1DF4FmoKWqCT7KI+IQzcfCIhEQXIdpL4BX2EXTECBRAyloaUPopSvyjgYWpdDgIQHAkpp"
    "6XM4ifd1oDp12pufRJTZPd7u7e8eoSRztLuze2yQ2dPIYi9OgfMYY58+fhrJZgKCnt8n2msl7rWD"
    "qJNDwJMpPxK7QRgPY07wUhB+M6B21rfd/+34eG/nbfrgrfcA6R5SPGjLNkCpP0+7UPbV65cney+B"
    "f0lkbwxNwyvQw4bQtak2UZBO6lIQw4bMhJFWjVVSNowjkCo5+8Mf3I2zySpvCAvOawvk1bDPh52C"
    "NkDjtr51jvHFr4+BhbhhQ4weJoKfvxJTYPS/6Hfo1rS2jS9+vX3hAkFVm6traoCDrzT1tArR07de"
    "7+Ez9+HIObtrP76vbdCdZhfQXnVsPdBjACpD93T47vdnp+67/3wW/xoeXrCnSP4bmuUrt0+YJfjU"
    "nQJ1E+eC5j/8a5deIZzhHcgEFl+MfF0buJBihXwQa4yNVqk6QRyqc8jnVbGmWA2qaX5bEgzNAR8V"
    "h3SBTVOYQ2JRE2IVeBPfOupvuUmEMc6TwbqCn9giXwbWIPI8qY17hfARQLkg56cwGVizPj20qpuZ"
    "vn9pTG5RmRSMn1Qckz0zG/M1Dal2IcOOAsQZ9qp5ePsmeBaUBBgSB6AMlShkO6CerbNqwSZOpdQC"
    "ymfNNPT9ibXWqEhjCRKnoi7AIJ2GWQ4F+YeThqRJHHuGtKUnD7VkohZyynZFJ4pjNr+PgaeNzLuB"
    "0+r85b3JiCwR2CYVqw5otixX7gOmZdU2lcBjg4GAaFcVRLifkHwCt23ZxH/bLfjQ+drCug/gS6NR"
    "bXeU+D9gu6AHuhkOADgxPkPhRgthqvBL2LGtVg2QXTYQnA7ufgtrPMTyjUePNjRD8MOi2c76cs12"
    "1tsdavZBW9dw6s9uDKhHFdIKweM0jiicIGr0xxY0iv7YguwMWElGMRghuF9KuOc7nri8YV25SQBi"
    "hNCF0oYs/DM64UbeHDUPERVaQFS1hDJlDiftzgbZQydbG2hhJCPPw7ZZ2n7arQESwwJ64ixdMWK6"
    "SMrNbF0GPo3aWK86CuVvo1JHKIBNzyehGyZf0R4b+oWHaZXlLO02oMI1+znx3cuV5ehATpnE8o9B"
    "oJ6/1i/RIjtLoS8tEawGNkxenituoiTHBhJggP4cSLdqyXtHfbMYfhSjeYg2y4cjtIaCIGQfg+7d"
    "e2lvv+jt2yQalQeMBpAPsDHU4UytwSCMiL6714LncEnafBuZGjY1QV0vEmUcU4s5qCdOGsYvu8Ya"
    "recE2KloXo9QWookV8spExLGyWn7jEQS/EBWr3MYTUMvaOl/BGmbnHakPjiFy1nh5HTNOWsU7z+S"
    "5l3BmmKsxTQKEHf8DFVySZ9JmC7jqeYO0GwZQM6YPSTi7ai9sGdN1/OsvLy6ONCrgHDC3uCTFMQn"
    "C/TRbuiOB55r3DjGzSkH9hlKylc+kApCLkXGg7qfQrvc2e29PnnBdUrYopNb6AB4/6fQJj0f18ti"
    "/MrIxTvb+GHqAi3yXCDKHRQgYIeCxuB30QYO3wb0gWMqGSPjc2tsZ0BYo1Es7woU1Qcgwg/wdWNF"
    "MVuVjOgS6O7M+NJ0yNoJrCE9B4zapWgVH4jkODbI/A3LmbhenDTNe7lZJhgToMyFWmYwjd79Z1SU"
    "08wNodGm8Ro2SmzsiQcJIGniIokeBehOl3vlxLjbzdku7WkcTMWIPnsoZCBmQ0FuH9EEFxsLX4oU"
    "bbd8tQwoaY5GjvrLhB1csJG5G10F6B7FitCcf4M9U+N3hBP3sGngc44Y92TgxRWu2skppolg2XTD"
    "UKgdR64XxCdoXNqJs3ab/9khvCNbnAevcCYrEhccNYXakff8DXsOW21gyD6PySVOWPRiNR5R+xY6"
    "T7otG5gPfWp3bNj2SbuLAKKPHSZs0Oc19pnXZWOzYI+lcdR9rFjUoKtiZ+DSS99+abQYeX3y5Ekf"
    "/i/MEDhJCwZqM0WnK+2zYTyNsm7E91631QQI4RxjICgSo2UWxJG5Iy2Tj2vnuY5xVwziHhZvGGcY"
    "wfXX/6dYw0K6pV2antuIeA09OhKLZNgI/9zLbomD412UnjDmzi8bNwGXeuiIIOxclRBmtYzNxsQP"
    "Ad+SAKbZfBsBDy3zIvM7PwEO/8PUd95G73/zDwbbFfneRBJgrMJWO8TH8GXiZqu6dqhuPEaakcAk"
    "odfYcMUoWdPcc+RqyIoEoRxuKD6ajW/qd3AZZjnDK0ENW0Qlxm8s0CgreP9JvK69w5PXRz00VYJc"
    "tXP8ovcXuz8Na2FSmJv0L4DApBfupS/YDNOVZG4jJLLN1k/JW7Ad8wijKJMyA6ksAvl65zMValLL"
    "P2Y3uSzHoH70zKGmI4nI70XBkFF5viZOTt1/bZDx0rijNcHvd3wt7lOV1NMIeudTN/GoKUFndnuH"
    "By+bTcajOHkaZi5nUSCyvfs9fEl8QbZwvC5IYtjuojwkjYLRyGZd5XwE2YFtXCcIlA/kHSXXaFmP"
    "qlV8K/pUcM14sWkXSG0OmUHYtHH7EnwbZ3Plbp3uInbHRmNJfbIQqwujM3mtyIAWxtdoCS0K4F4b"
    "VXzjfANMmhduGrq3UIXWoeFUAwqkKlJxWi+NUoOclwycwuo0OaWiZ7Zrm2ZDjI/EfpeZLYiHU9gl"
    "MHD+d81snOk0LDFdrhBQbzPGLLviZeECR0j4Z1V4dzgKMJiwOxJsfL2gZPwvBo3HidANVsoKIDSP"
    "vsKOChy2a3ughgDPuMsLCt5uQR1aArGdvRgfIQ3PSS3MGPliCExP3nDlXswTEhPdKcXvJyBj8nEb"
    "8dSYLr6hJTpRgmdBi4qZVaeUlieUfmFyIaUchoExiRi7X7g+kh9giUR8B+mkogzGteBnDPkANXJk"
    "XqR9RvmaiT8JYRGtVWfVXl1t3DfVwIzKtmd0xoLObMIKoLZsMsdueAX0eAw0FV7emyXZao4YIEni"
    "QMMNNzZSaM9NoDWStfnCfcNnqUKTOV5RJh3cAgybSDwv/BtLnSFoFbidGko1UBAY0KbskIG1KfmS"
    "ojgC+qm+X5NsO+m8AuNg2E9IWFYHnMcDIQQXNjDS5IA4EIqc1VpT0EaH9pQnT/T2Exft5u71aXvN"
    "Wd84qwnHgMnfWoMvuq3Cru8CpeMg6Rqutt64w9t+/Nh5srZE2+MONM6g1YUvuqktQEhpdh3JfJ8T"
    "0pxQFuS0dnAdkkDgzxddQTudWm6FyyUhkop/bqce+eY6R4rglg+1myoqDVs502F/bTPl31P+ne0h"
    "kNtZEEOlaZNPkpXA2AjTdydxaDocLQGTT1tnDV1NXFcfLWj0CV0F0BFSEDPCaqZT0MGPVBl4ZOJH"
    "awf7B9/1jGev97d7B0bbMXb2jg8PjvdO9r47ODb2exTc8GmCGHggbd8nn6eQdE0TxHPgl5FrWKJE"
    "MLHJ3tcfuKnfABg5hrXaftJptje3mu1me9U2iq+rDTwjhk2dX9sG1uA0yC6kbzW2b15w3DLxcMGE"
    "S4G1JvQ/WpxbMKlGA+xGnp/4FAcQG3uHV+vNr78VQQbNMzXqTd2wYze9rEQrvDp13/3uDGT1xF24"
    "ofPr6rCes4U2Dl0vYfEJCzcHq4cTrRKEAG3w+Gp+cB5HErPJ7dnBRFjum2bj1Fk7q3SJk6h2eY6s"
    "Cl/Vd1n1RC6OWSImfQHcyhFlAfdGeVFhc7rTMCOrnwr/Chj0MDCU2J250D6/1kK7nuSXQx+xweKt"
    "aD4nCKZc9vy6KEnLRcUfwGh4OU5NBe3g4Rn9izjNInfsA25wQqXQEF6Lne9EkRPLD26R9WINEScx"
    "N7YXT7eyDpHVeHHfTSZFl0DYnk5htxmvetswG0CC4YVv9I4O0ajF6VZTUD9lfPOR7NSErtD35oIC"
    "O1mSei1BuQqErCBjJawKkM99ODq769yfPnTOPv5bw6zTvTXEpYrefI2qgUSFqPMQICi8fQsgsFj1"
    "atyRQIMRHn4a4rkMxAiMs6zyyaIMoSxaR6M4NdaMSRLgaTwMQBxmUDg1LAoYBzFi6IaNHFUmiT8K"
    "buI0P1lLHbRazgb8bsKEvnt17eIq4rPWttN5UnrW3nbWO/DsEBhBGAKNkwBt7mw7vU1nDd8fuelk"
    "AKgBlB6dt0+3nM5jZ/dp5Y0yiM6G02pBkd4EdFk8G7PubOw6m/KjZ1vOs2fOdqd4VLSwtu20N5R3"
    "NOLHzjNtcexwzWmvl4o/dTbXaoo/aTnr2+icmgRoRn70NIldDzRvVnOXvz3y8dThZaluu+d0cPrb"
    "AejYHL49Z71dPCqKP9t2nj2FX7V4Z9PZfqor/rTlbOPg4N3J4cOXQXSJZ9Dg4WPn6TP5YVFle8tZ"
    "6zlrG/jWjzyXz32dVXjJjlCVZ7Dl7D5GrxU7a4XrA4NqO0+Vh0WVx+vOTs/Z2kKAecHYvcHDatDM"
    "M6eF6/F6EPwwDTIFB56tO086bAwvpu61H+SQfbYtPZPmse6srTubCJZjdqwNamwD+J44u1vyw6JK"
    "Z8vZ3nG2EfCvgiFsmZhOT7E9QJgiPVYA0NoBoFWrtTvORq/Sl+KkhM1M3rlvTdID3WGVHTDby4U/"
    "DLxY3qsU3jU8dbbOBA1SI6rZfkZGZLEvdqmtRjnu0AvSSZwC5K/i1EIyUrbCC2LxzP3RmI6J60yA"
    "5Bv+GIOcXdCtgb08RDHdeNRZN3wcDJEnueUmNfE6dbmnAXgvvY6CKz8kVyA5H7HdBwYwJOOh21R6"
    "L3wBxhxngCG8AXL/SizlKwrJRiWHDQanhOAwgMwGKSjzE4CUQd5msqI11LBL7ggglblwNdBXrf2+"
    "Yt7QG7phFLaxm134CcAjKTtGC2PRd24CwJ4mlHKDwH6Hy3bfbCH40T0GLTWbNaY5vTGcmX5S2+ij"
    "tACiR4Vd0sAsLwXgV53KjUfQpTXBtxgdmY/G1KjGQh5YQ74LoOnKTk9VaK0E4/ShzvCKDDNRqpX8"
    "UZIYXp3CcM6akzQZVsrg3mNlaEZnTSikbCX5B4U5DAeThcBq/KQ7wG51HLtSVtkSeTgPSPgOqLpo"
    "biBTA54WTTPTwX/xWO3AdOCf+2pzDCEM4y6YOL9ob94bd1D7Hr7TwAFgODb0ya7e00HPsd5OizEu"
    "vmfJg7MNNebllOKKGoUV74YUkzNJgj/7AMNnvvNGbngRTw3rzr9v2MY0ZW4mIAcPgBgwZFYcR/km"
    "7jggOADVSK99fwK0I/QDtCLjHpC8YFIRIFscQ9sPOxvrhjWJPTy6c+Umxr9ca6UNZevktAfHUgjk"
    "2m09HGMMr3VqYlmUqDHYET0WDzHccR0PcYOAvaI3wWmcgn7ZTZFL7KKDoejgDfsAzZcWuCr8wyjn"
    "BPl1tEiSNNkHDKdkJ0U/4OQpXztcDhdXAt0KIDbGKzlZBPo0nAKBi7LmaIpjTAV9PKHMO4dxHLJo"
    "oDhhZHlCxD2nO3cBD8wOWOBedO5bQGI6GxvcVeSWGcJ1kF1oWocdfNPHCFUf9JnNVoOQ+EZm1Ris"
    "jv4KjPkD8dryb5pjIP0Tyg4E42pw/KHRAEHHBBE4qB8D1O1SW2pC5WVYUIWiq5AMJEMrJZ8KK9G4"
    "V9ke9ABM1vPxgKzLdlQZu9noiKhSHUd2FhBlU1XSlYWo4yJU8SOp4cpPQcI+sSEVyNN3uy8Ptvd2"
    "enjU/ROaUTFXB4hvmBBkSOE/ll5sO8FyRlEMpQagL1EIygrIONMJfeAUl1KNYMsP0bbPyU9JUAM0"
    "Qst28KNrjH0P1jYGRImmbkiGoxcnJ4dMcjvKxcBhRmKJ6LU/HiDys575F0TM/hgzZfnJVYBhGR8r"
    "/X1pnFBeMmVKJUFOvJp5hIZ8pa818KmVsUTkgiiMlCNVbW/kWc6ax6KIpfHPkskHe6UcUkkBGuq3"
    "ys1J7O8PoLU+Fq1INNToK1gyivnji1HXmEcnLZqiGMi3j4x2v9Vq4f/1zbJFrWt0yhplhaBJo7ZR"
    "0gSwLD8S1MQH6mxhikoJNmdSfUxEWCAJMIhv9SLPnSlmZjpeaJtsSKYzhc/EXR2i4qaAuengJyBK"
    "JHVg3KiMCTwadCnRR91qWvlH3V41UpB2B65UFkYiAKwsev39CgqL+fppnzDgNB+5ZW6H8dQbhW7i"
    "G1Zn49VTNA6bF1k2SZ1Hj2g6zWFepAk7/lG/j1D+lrxl3c6GSGUDzFgsuqQgqB20W0t30M5z5Rjt"
    "lraDZy7sOSRFw4spWkCIxIgOQOtrjniBRzxPzaN8lR5ddb6lkt0MhKV/msWXftT91V/uX/7V+NmP"
    "f/X8ZjyI9i9/9eavYvbsIvnVm5vxP50m4TZFh+DZ8/KkufjhhUQDUR9rtnKOHMWYXBDqA0Vzx31g"
    "4z4FUALfUtZoDuEamTuC1lt32OZ9o5Z8ADtBfk5nOvAfq7xzfiALv5qRsAlfY+DcFhuqECFL50Tw"
    "JDbz/fzQRDnLkudUimwK3Unqe+pAjIdseGU/hCiM4beof6MgRKfC4UmbAbuqJhYAt4ryXxtbSOIs"
    "0eLXBWGq07sEZB3jjjfpNNuje+MVNm7d5W0/ylvi75+SEsJ7omdpoxw7oj9KtDB1eSbRk5oYoPKB"
    "I9KRLKQ5ZFnYIBqcssifrSb9xxpgz5WT5v1C1t6YxUuz1gwEm60/dVgWLD4S86fTozpyL59AnVqr"
    "eM8qqpQmeg9hLGRiS4LYw6zV+LqtYOWix2u4jEVzGJOWkjYeURgCfaSAE1paCmRvCbx4PWFITiHn"
    "sJNR4SGkQHI4gHUHPEuDcQBEmZ2aqdAzBQ0WFBdYP6U4o06+JXFgnVdPV1TiZdRgFyNdGuJ1xP6q"
    "5q6cI/AJNuPk/NEEdRC7QtS6NE71+QUQONQZ78xt2GLAZh+e3E58kBlgOUN+7v4ROWYephls77Ek"
    "PhRjriGz8F1PZhejmyrNdErSWYkuol66GGFkREdgyt20TA5l6rZApMvIRK2FVBWun4z09ExWASUP"
    "ViHbCWIvme6FqFfMWHrJZD9D2i7Sy0IYNGRZ5ZHYCbKDQAiKLIwIBS6TOwI+gYb5z3v7uy97jtH7"
    "bu/4gGUe+Rev9473TihU58Donezu7+ztHHyafGoE7D4iYgCqdZxaEzewcUUy3JUO2T440b8OMMQ4"
    "u2yexJPQB5kTyzbEK0DKLPRZGD5rytj3kZK++x2ecTaLguc+iCpANixzfat1s7bRkt6Jk0++NTjv"
    "bp/yZMBnUuXEHfTp9CAPMr9svnQHMBZ4yT3ZJkLo3b9+978fUOjs9sH+s73nr4967NH+7vbu8fG7"
    "f3W01ys7jkewo7sWbuw0DjHbabuDmUhDr2LqVgYH4KKvIunvWYNl+5m43m3Xam/Z6w3dYNUW2cjR"
    "1YoKQmKQYg8dvPs9+k6u4uG7/4IeoGGQysfDDNBa/fMphi47c2fzZKFZFOmCxTyEKSlhq/8Mk4Iz"
    "cLMGeHJlaAFmfNNtb9KH226b2xpHCWtnFIRhd/VmlZfrtKRyhbEKlHeUN3IMLIxOcvejpNy7ZJ3S"
    "dHcrc+p8GUYCY97/3d+DDF9d/3bN+hfQKyZfQgIb0NXLLqBfNpw08PzuauiPstUZI8Hp2wssXf0A"
    "WCpo3XmE68SFfRud46C2APjfT9MsGN2KQWmGuRjSivObyjlG4P90dC8/h0UHs/jpxiQJzoMEk6rE"
    "Yxez1TB99dNjcKl4PuMh9pesyht1q5ju02mWxZFMUZ75wwvF411HMFp1CMNGWuQTZ6PFvNqjSrOA"
    "QIE/6q4CB8oAfYfTJI2T7iqeAegIdN4sVwLFFliR10UiiWchk/hWnt668A0PL/whZaQRZLrvXmEK"
    "aZAHhF9T7D0l1WDd2StRWMizEjpM6o/gGdYwxHOAhhckPoyCTjWymkDVivINs7HAYa3KGHQHt4gZ"
    "+BpcLbrQRYzOPr5V6Vk6yqX2PHCDGx91Q2qDDBVorUkQCOUjj6bi+Bd9fDrh4phSs+71Xh48P/ho"
    "KWIImJ8aO3THQtxjOSstSUqQzvv1+4ABWb9vpX44QkRGV5BtXAE+BvzU7EACLmXCtRrNvBqrIJ1X"
    "gGaa6Nsj8T9vRn0/HHD1YDhQX3CBZbvgpvlBV7PURyGybLRaN+udVrnATLmlaKYQXpTn/WlgSe5I"
    "/IrPZWVbEGGCnNnb6R2e0F0db/YePtvTRcBVadPaXGYmCOmoIFZlaWazkGaqQgFbVo1UcKskF5kn"
    "EGyVjq6FmLHdyvByj/iydExiYamgTjK4wSPkrN9O2YaCkysAQdlmL5kCzZ6y+x9Ua4XE0s33/+lv"
    "TbkWPPiPddGKS/ASPf+HRYMR2wtIHaVhImAXkzj0vRZCR60MQbofreLIVPgA6JOrx8F4lSK+i3Ab"
    "gtbqPlJRpJ3uIJGZCAY8FIUblR6I+mPLOY1fzf1Cq/RyVXTxTLC6OuaAfSlcp9odkfxqdxK/WKYz"
    "qVq1K5bPTenLsCjGgrmR0OAqzZUVzyd7MBmCSu6GxZxEkjlpmUqU5tgPfayFA81P2DuLEZzWkgRH"
    "xSIQSi5Q7LletQV54DSoZXdUGtSpI0IVMgxla2iPcoiTZ9mtJGIuE/3xAIWkDPrexs+D+AZoUIdJ"
    "jZjbC6/g6QoutUhqnis3nPppl41Ap5G0GkKx6GzphlPZgXyCVsveUnN28lkK8UaMknxsJSIrNY/c"
    "i9XEw1EK2nCxGQFgvv/r/2Hay+lT8pKt5ThR6FOqVFwSild02QCZQMyCBBx5EgW35vCuLLTuXNtM"
    "6qZum2ptcz/OXEecgyUnu5GwjAX5tiJH+hgDn8ZxhJdtaVJfQEsWHpXqhSPX6L15fdxa2+xtv7CN"
    "Q7wwxDjsvW49aSy0PbeW2pZcadHqjHU7dUuLH4yuAGs0mGnm6FXvSMsUPwh9ZA2rVsGqKlkldGLD"
    "n4VVTG4DcaREThQArM8AQI1KuZjeW79f6pXf+bOeN12NWtmRxdb4siy2YiJYJoOL/TdQ8snkliw0"
    "Nd6pJKhy4loeA4rLqubBk/sspXhggO3Hqh8UpNulpr4pFBJJG/kmV0NqVRD5MP42y/CU1qsg65ut"
    "m7XNn1sF2dk9hu27u33SOzK2X+7t7p/sHosYqMXEg87y+ggXuFWVZJ3EgUUJ8ci8y9eNEG0Vj0Sv"
    "2qvfrjbu4X357UB6/ZPRVdXSuoRipTG3LmRylcUdhrT9HzKPdXmcJUF0/p2bMO7YRe9sGdmu+Plw"
    "XXE5twOZdG0LM+yjBOSNsgZad/1oOvYTN/OtUwVWlvkvirRb8CuSSFitLnq03/0hmsYNh1L9izHb"
    "BhufXWoIT9OJbGkYjDB894dRMIwx5+qPQdylvO1yU5Qd35TbOSunSs1VpoTbBenigE+lOp0ngWcl"
    "8XU3sIdxOB1HmOUsC4aXt4Kz3nY3bCHMwQpWFLrdCOmDGF0ufyLg9ZLkrGGW+Aq7ffDMDqLUT7IB"
    "IBeelwPOIL3TN6eyHC67tnTzbUvz1YlWMDOJeegYxsdtT93KiP2Zj7ZTrA77kE7cCJ6Wl8ratFsz"
    "9Cry7jmUiiWNyfxtRHjYxmWnPuIpCYNoIU+CH13yAjUXm9+SVLXstSoThkHGvX6K9CJRf3OOXrOk"
    "GKeT6DjZny3QLSXbPZnTgirmUXRE0qgAZpbsJxu86mS/z0PQk8UCBomKaIBJQxj/oAsBcuLMNmYl"
    "muU7ZBSUclBU60ghooyzFGSZNZJn4weOkqd8UBaDCUAWaHIZKGhekCL1A9Yt3FQ8IyYGpJSWcjrB"
    "G3olkYhisMtaMHJknlZVlRF46lzMh2KX9OhaNCPORTyHS4eNqsbtjtCU3uJFMIE+iKwSVonbipvs"
    "fIMF4iN02s3wchS8Eo4lp2pSkIiyitASFykSWd7VAzKKk7Eb5mCUd36jlKkXxPUzFWbFNc1NzAyO"
    "waiE78Nw+u4PQIVsrIapEM+EVE4YOCu1QqlJOpNuUZal+tY+xZ1Hhy/3tnsY9n94tLe/vXfYe/mJ"
    "XCe9ycRZqVNV8KrP8hrhM+7TwI9FJBR84SrFyDx697uS+9Uwru7YvdH3co5QrFQoF+32RuvmsaJd"
    "UIm52gWVGoN4EPzo49UEgLabW7KY+aWxMwkMF8+XR3hdlVXcHt5YLm2LNqVU/bV7RFNKd+4N48Rv"
    "HvvZIYv2g5H1xMDK2S2WzcaX04bUYaZbOkhzelYtAHpY6LAjFF3j7r7i1mL6o8GXWidqs0vAyrI5"
    "RoOn+eiqfWctZfhdDT1NYpYMMi+i5tWjMujMT/p4sVB9mYu072YYvK50VVI90+w29CsKKYu0qzzO"
    "3EHFENvnTu0A82HGVh5Az6+pBm4WhPGfzN3nxVZnEy8x05RblI/LUGlmF/7Y74PIaOEVxHJAZRFU"
    "jk4rvJfRMp8DQxLXmTdsyzzC7/yacvz+FL/z68fx+6/wO7+qvFEi46m0/0GBpljz5gsUTUGCccPm"
    "CZEZ2DyDGpOWyOKSqw3oqoKNHE/PYS+GIJvIEo6B95L7CdMVWjIIimGYJ/txRlfS4tVGij7Cb4lf"
    "tp3miTuoGbymfRonwN0vns8RyXSGvVwSRr2ckq2gi/VxQx4rHjucM0ppfLDyKfpsMh8kEtkTelaN"
    "XskHX64kXL9ndTAT7o4aeI0CP/TqgFbzvAZiMoCFommwwaoNSZbfMgEYguL17vcYZWr8aREATuNK"
    "FODCqxh/iOcrXi3C7ws/OL/IuhtSkkeorKoljW/yZ/1JEk9cTMBmEa3WqadQVoh6hnH07l/t7KHE"
    "c/D8qPcKAw4WM+09XkwJ7RRBW2qwQdl/VVGnymPFg/KFdPMpzHSdWSGR+vGpTCkchH1i/TrQvv+P"
    "/w6hun9yYM51Cy4fGbAosHUDlieYIHZpXaSqeZImpnZVtUVqmtxqrNQb1yRLzx91QZUx1ZjUVAlt"
    "kdE9mTO6tWJ09ea05YxvpTBCxgXbW406F/F6Q+vNLWJk/68F3XStRawYlXjZuUYMY0krRn84Ohcu"
    "3Vrfbc4j3IH7JyMh6pkFSb5lYREnGg24yChkhIJlNMolZd4wiLMLACtdxurxg01sX4ogU2XHw05P"
    "VUUF5cDUUE6SMuM7qT/sCCa5rA1xfWrVTu9OPXR1By4/sWkYvdc7eycHR3s9drmwpk6eDTuvI115"
    "UC0uJw7AU6eGNv+prmZxsJZ6gprSgX9N+WuQN+nyKlvM+83B0c5L0Gh1pcP4vIARlX558FwteKaI"
    "+HSTLij405DOihL4Z4TD8SWvDYYplvUUWj7De0iqRihAGbxXSQSos97LvA5xk19yyRvkKHCmUd/6"
    "+ZLnhQsk0FYoLpoQFQoM0FZQ8l6JOgoaaKtJ+RZEJQkDtFXEiucVchTQFqcDULwkLn9ZVP0sfvmI"
    "e097DtvXn+kUBFXlmCtiAwKJvg5i71beUnQ6qmY7YdkPJq9++oPcD7ZVdfjy2E7lfGj6g4afswHc"
    "qsFf3+SFF9EDoKxtMqr93d7xu3/73e7e8acK+ys52lTZX3WntDsi6q+jRh4La3Wfwh9lD5VqvcNp"
    "PH19vN07YrhamsPCw184vGi+8+mxvTLD18Rz9zX0M50Jo5a9qQZG9rn1MccrBEdJEmuUy1dxWEbh"
    "co/VRcE2BvEN13zYF6vEdKijBXzn9a6vssQ4xyRgs/eSPWH+2inWI/sCNJcQtZfsIhheoqUYHrpD"
    "YCc+2fHQUxL5qw0tMGbCtKbKIIg8a/UXv+AgpEjc7Je/XBX+IPiXKJdO8URHS5+HJuVburoxNC7I"
    "Le0K1LvGbelYWefxRjlCcMbQZqHymuI4OKTexVkhKcVU0q8jmhXqjIWrlLJ2ReRNUcCR9YNNzTh+"
    "mNTMLt+gFZCQMwCludrV4o3K8djTMYsVmEvQ1mcRtNLCFupYEdQ5a8DaNVxXA7X1tT0/mz/bT4Gf"
    "8ycCQ5k5Dx5tIyHk0zh7999B9QG8YLEZ8uoDqU7r0EUTkE7lZ2BLlQ+QtExBhowQwDOLt1O62f5/"
    "/j+//beGsbe/t70H/K9QrEB7Od7df1E+AV3wYtv8klJyVPWBPswmF9fxFiTV296oHa4OxK3qbs+r"
    "sYsrF5jk+//7t6DR6cIRLXbDakM7TRFUouMDrEvm7O+zlLELTZWNecGZIpbH1+r5JTa/GcgCNeqO"
    "N2uGAxpPGYDQQAVJ/vZ3qNgeadXiKuzcH6fhPAxRc/UtAjmoUEeebzQSCGyONe3mAIVt/pTf/x3M"
    "GDAEsaXQ6KtTTeKbOhRRjhWAkszkC2u90dCOaam5rdklevMyPmd3IyuyWny+FFeC8guKIZIxFmuh"
    "HvB87/jk6EBHjz9O2i+fHcgly027XeEd8Xlf3OLOFhifgHyGoTZsqHU1lpNpC3L/2erlqhHtc1fQ"
    "C4vRT6OkV5Bhy/4gDV2czJqnoOf6+cep52pqk59ZO99s1JsRUIDG6/ScBQS6BQNya6iHRsaje/y6"
    "pSG9/81vzUUO5H2M822ukF0z2Dk6/lY9oN9w4yNl+3V/FmhfMw2vDHCeyFiYwxv3mG32wk0Ni+7d"
    "jNzGQsuxbMTzwmvC3Wj1E/rwRXkhbNU/y3pcpNr1MPcB/NNxcTHnzwt+6WxP7RTmrICqo+WyF8WE"
    "lZQlRgH+w/+vUY3makRcxGWt2pVgYxZd3qgdx6JGj7weRdnpRv/3hnHYO6rE38vmspImzJqgBmsG"
    "vtmoGcCsYXf02hvqTh3NwOu0tUWUNJ1epp/JVqN2TDPxaEs1aCp7RnMW9/3f/T1P1PZy93nv5dvo"
    "tf5Ax9voI050LEwiZjnTF8l9xMN0yczm/tHNbJguaCmFBissYjiBolk8KSnaWHlm61BlDqZojVvF"
    "LHIVClqypRvWKSPmyk9NaWceNtMPe0YoTF4Ob12OdfPDS5NaizGRj2QhS8tUNOZqEFKZQrhJ4vJA"
    "CimcNccVZuQ3n9fHvY5jbNzzYXuNgwiokraLZQQJ6Hu5LXG+gNlZXjrQ7eWIhnH6iMSyT3TSrLxG"
    "ZDj6AMV/6EZXbipAsU3f2Oh5AORmyy55inTemppWl1yQf5RmF1DAlzK6QPl/dCaXPAbpc7e2FOE2"
    "H2Zt4Qch+eK215ewvuhEL5I3zO3e4cnrI3JdFMFeaNv6YyQ/0/mQ1PFpZMNtnuslNnKAsrwvHj/k"
    "y2+CiA0vCaA/g+UOfMBvj9Mnfzkq54yhI0AkWqZTPAHlG66SQ2YxGfPJhyctUEkJbOZOSRVzr7TS"
    "o/llx2tvoMxQVj3cqxouphx6z+HvXtmmYaAkLoviy52txvC6MTD0xYA1G5eKic3wqWqZTn2Etdba"
    "KPI/zE//oOVl/ICWGtIpJWzAaMP5CRueHh/v7RgWplsApEviDK+qTSizgiEOxiLi9nrO06fO9raz"
    "s+Ps7jrPnlXjIYGxu6Ejh0RKiD/Elzzec7Na99g/Rzwllyy3aeQtmTylOg1ps7VojgeEwc+U3KFT"
    "Su5wpT//h6tT9b9d5OGcV7UZItQEEfafVnaItQ/NDqEcGfigJMp1y7a29LLVQrt0dmBB0H9CsM9N"
    "yLE2B+TMTb2wSYAVX0RRl48dYB3MI/fvjR1Ot1Me+uJ67meVNgvtl57LQrWqphE5O1/VZIUCQTUC"
    "IpeGjgpZaEHDJaeNCQyq3lCGCYqXGKgyMtm0ZwE3efd7NwH4YX6rG2C0jaXNfMVAZ+Xfk43F6qkr"
    "Jj5+oGViOW/P3PR5i7QhxdNtgl47N56OJqwXxda10UPAR4O0ZFOuyrBmb7/3cu9YRjFj++BVfqBh"
    "XlxIjvqiPxH7ukjEEK9SI2C2anyNbKVfHjx3PkhhXlYByJXdC21AAo5GW3gRBeizVYL1J2uQjOPN"
    "mZ+7ZqycK/kY5VgntX+EcrxA4NZywaH16aL0Nrwl1OJXMeZ+NigBm4ECu3ylLU+DiK9klY0pue55"
    "nLg/vz5bdSfME3+0roTbeq5/hbfAV+I70cyui9zjpxtkHFiMOLNuCKnr/Zas0DLiADIlbBMGnLmh"
    "zlewqK95WeV7Ca5cfwS6GPoseeNL4wSnRLfpyRisLPsgnKfDN0rlF93/KKBHLl3nhfccswuV6QJl"
    "fiEzfMH47HJumCzxfe7jOIGPV4F/bbGeRTa7Lm/axuRKIOOyFFPpqjC1K8fAySdSl68EvytJI3iH"
    "iyUImZdnY5Y0NTP9BGg4YiqbM5qoUpQFptZ8wcC18BSl23uUKQrZfeUD9oWqrZRHzbKJ5EsxK3WI"
    "nFHjrJTUE7DENij/5TXlmymZYxAnCzq1i5eU++9+Hxt7h/i8vd6qGHAIgQsm0ds2ep6HrjWqsFmt"
    "IOO6YT6Tv+kr0H4QXZj7eNwCeMwRHaEwOkqFM03+c9w6Tb4dLJq+yAHaqCnMdhQry9Tsa9uQeWax"
    "NOIE9/EwicOQux1xVxpxgjlMu6uwGHhTEiZiU7RL6ukWF1Oz1SUcvU2p6bwuRixnuiqLOu9VF44S"
    "ezTQZHyQQx6lO7+K+OY6Klryt82lomFNUADLx1nrawO14ed3sykB+xU/W5Hvpabqop7Mz1a7kHzV"
    "O39uuoV0+Pyj3G4i/+jmJ9EsqhD/afQKdtJiYb0CL5lFT5d08zn+8qtBbXGzqG8AC3z3X6IhXW5L"
    "+oQwRP0sekRHPdax7SYeeSzYNfeg9siEbEhvl1AzqEKd60zpmi6Cg9KWyITP0jqwXPhXbkh55Gbd"
    "tCTqaVOSF2nGN7X3Ly12Cmaz9sIiOROFvbyGMOPexFI2duW8z0BVZapJtglwK8voMp3OQsqMZsC4"
    "POXh6UbNr5CDt5V8715Ym1YSg+MrCd+nS5bHK3Znli+UGcREgb8gy73/r//a2Dl4s//yoLeDAls+"
    "YFsxbDdmNPDXxutDUV2agS0rwzPq/7v/Zrzsnbz7N/vbGBGsTMk21GizOgL1OiKylDrsyni6+VKi"
    "Vsb73/wDxluxFzmV+qlvGKg90ErBb5hxnwe0xejNzfCiZk0IGz9kV46UU8/lErHiQXNPF0wWySLo"
    "gmheDF1xom62ReVTeqq26o4b9hFM2uO4n+TUIU8eQ31IQkI1y7hmTMuabbCm6j0Rbp0FTTaL+8uX"
    "RN+6sS50J9MfxTEwW7KXj6WWnAS5WF89v8Eq/lk7DIQ/6XMX3/NEUJ9EeP80MXMI1+Kw/7FRHL/6"
    "YwfNaY9V5XlOpTGPTEx34hr8VJhj6I+NfTA5Ws56PPvCjLpJ1VCG9TJvWoIvLXTMIU4MvMtzOPZs"
    "TK88OtdZ5rbRnn8O7KoJZSUjHSNNMIEhLyALW9x9zThSxbD2Gr3JobxsktjFzs/RU7vufBLMtdxm"
    "zwso1iMxxm40dUMK4xO39WCbrihgL9zmsRteVScujTOlArax0DjPKpFjRcpMpqAsda8qrj1bte7o"
    "fOnLDvGHxxCKqCRh6QN0mBF2MsuTfsxOaNJZ0tSwMOHMJE7YZaS2MX73hygYx8YWis/uEFbYpwuV"
    "Pj6AcqmLQYnldirSDAAfVhRZLpk9fQ/b4OZV3zuBLxpx9ROmo9KFZImCdfb5YtzLpIviNViH1mq7"
    "2Vq1zbeR2fw+DiTK+bnLCSC9fe4iAiZ//KiggU5V6F9GOvhUHEcX/AXCRjCeoEI39wAqSrUhFZ5D"
    "l/T9KFRcy6CkfhhFXyByDMqOpmG4RCAPFv9zlcxf7L483D06Nl7vfc57DjFGvfCT7pAfnKMJzTaA"
    "MXbxOpI8P1F+0xE/kFDsUG5GK3h83qBg9CufOKYQ9iUbJ0oDyyfCLkSC2y7+UzgNUTrkE6Z/5Xuh"
    "JKRX4SYU1JYEk+vFmatoZsFkbuUc4VpnuI7BaguWYFe9HgwDLkGaAP1tNZ8p+6NesJK55/L9Knjx"
    "iKTz2Jbp0x1UajaDGYtjmZjVgCpwg6SNuarHZolszm7DvQpS3kiumJRE0+smDL3Pb/WiWUjBBool"
    "meP5tYQTAGeODAwz+CaCZmjzSAhBxb24fG0aq6a/VKyhK8klGQyg39+h7h6gPEN9NvCGKPjLbrSf"
    "XUHbeOr7vGBj/ijrYlTprqv8djaYs7SJCiY/Ts+1cMrQqYMXzuGxlGYUX7PL7Ub41TK/euF89cr5"
    "6rhsUM8XImc+sIzm6V2W3p8Zd9DXPYeQMpR+MmcwmrYpYVZRo8r6rOKV0pe7fF/u1PuQni6W7+ni"
    "g6bkLd8RhdN9QFdXy3d15YfL9PQ5SiLbL3YxuJHytBx8zsKIekVZ6RoHIuKpelUbELoozowg7bve"
    "GDS5ElllVZruZOJHnmXu3vjDaeYjm4+NHlYIMMwWT4iShwl4KplLQuaVwnKT0M/cVL3EEXvEfAmW"
    "SYdQzdmdUhkjwvOTgJeZG0J/xvvf/Nbw+WhiY088T0zdLX/dbn7HnwHSCfUP3fcjPAo7Z8rsuCz1"
    "7kd4PXSyYPfIzN0rZOOsRU2wF+4ePFfKuGsFRDPrmb3xgN07LV1v3zROYg+NKSkuxbvfs/SxGPIU"
    "vfvDlR+kTXHd/We7VY+3e/tobP7srwQQKdi1l63kidjrrptlt+VQUPb+zoHmtll+z5KQx/L7oEQV"
    "s97QXHflq5o6vp/Zcy6ALUqW5yjya+Yl2N0IMwUg1vuY4voTIT7QH7lP5b243ZQKOZq7M/FuUyXh"
    "qZIa3fOBdvnQd1mUw61NAjq7gFPdoNjmqZkGeJD4TNU74JX5/j/8H/mviTs9/WX3cYtJmvLLvxEv"
    "1zdKL/9GetlRXv4Nf6n0GvEB4Rnps1On0zlrhnjcy+p0NCGlYu4laXdkGneDe8O4i+6Nu9RZ8+6/"
    "MhsLoaxQdyWEFXckzMfYEaEsOWfYIt6L6xVmxteTRApiK2L6mVod/1ppo6DlIE42gCiSkiQjksh7"
    "z3GorxGUhBlHwAwVZopsBhZoVag5VgC8gT+nrbNfdnFQBSKWL4EmDUl/l6voleqdsuakq1dhmQ25"
    "CFYRq1+UQuzUlCohLZ2GrxZjh+SLYnT+vlxMvbP6W2mx8byloS+Or6A0JdzQufOKjPAylmAfs7Ku"
    "qxhFqQQcQGesdo8+GEoIYNzRtPDBccAeEDjuv4Indziwe3PmPQNqL3nz2y8c3rJZl4izOheF0gyQ"
    "0ljlROd2OR+4raa51qnz5TSBdiVrXQkPB3UK9WcrPuz3vtt9zjLZGrv7J0e7aPf/rOUIOVN+zcVt"
    "Im14WyZwpfzpc6qufc6enT+bLNV835bXquAwEptgvCa/ZHs2g9EQ8ArTuGahmdyPLQJRKnzuOlS7"
    "Gvtp6p77yCDxsNe1m0R4tiXPImzaPBiDki+QL9hPs3e/M67cHwO3aepCTVdq7wjX3g8u3TPeNVBa"
    "rb3KvHqNeZ6/jUuDphuGps6xg8nI5pgflbK8PeZKLUuYM1qVzIX1+V8XszAWiVcXGniNRkHba45K"
    "IW6E7xpkjiQjZOXmukAJLJ6thRDJ619P3I4Nj9OuhchqX4eNeUoJzVdL7BQsqmJJHbDK60G9FMPj"
    "8iMNzxC7Rr6GOT/WL26x1+GWZXbNrzc6NlnudWhijTR3Wv4aJBcSQwoBt6bmXZ2lePUr79FX40df"
    "/coQJuPVBjZXOw51oPL1SolPNqI8TZlMOAAKaJi5SJkcOA6GfUxiVrYMyf28ZnnNiqxneZLpPPUZ"
    "NpFbPBSa5A777gS3+0V6arJvJWUNHw7DQCoC30pl3CiOhr5ohn0rFUmVIqmuiO9O4rDv8SL0rTwW"
    "AAfPL0+DEdApSqESqIKKgOqsaEVADsEXVdDZMO/UeLW3zS1eN6AivfsDGpY4uD0/Ca54NjOgmgy+"
    "ZfuVfkTl7nlucM0C1rVZbuG5n9CgAK/e/cPYz5I4pUEFPOCdIsvZ2Wk0S777XRLEIEnzbG0sWJ5s"
    "lYnhFnuzWd0tMs7AIsRpc0o9j63NhhZrZhYSaKMWWiur4wuVEsijlmp32mqxL3H9YJLEYHF/ALTo"
    "OJPLQ+rIoks4RmDxkIaiJYWttIfvzkHCzMaxOhWGlQJ2p6jV5oB89Kij4vGEsdjJ+NLCiowqqgOd"
    "dFiR7NJC/wbB3BZgtTnobA6cRt0ugY/WpHPqtDfPbAGiRh0lGbEQtIdUFzB6OA1dLw8y1OCKBIxm"
    "hRSWcfQQa+YCOpEkh2O6ryRtjFy8HbrIgyNvAj3Z7h2CkspA1Lzwb6xVZw5tHpknGLCPW+ZOWSkR"
    "8EpJo2ewCvOhlrgXxhSAPdpJCtIOD1orpbx/HAuVhH9iKLbRblQIWYk9V8nKAMB6qeLREA8YWMEj"
    "ZZ6Nr9utVnWpdIbG6cTr0ykQG9uycdhqUytqYGbLqBFuBOIzvKep1yH+B+I91ZyP8mO6RNuSxvgw"
    "axFENCBhMrHwgozTxmJQO0/cUQkysH4wwm4335/V5VPwhyA0i+yjvHJ6F9w/KuHwGQg7WNf5Radz"
    "b7z/T38LCv72Aej4vZ3eF4Z1N06dZmt0PyZ7X0Uk0KORnovBlIJfdNst1LGCrzqtbpd97HaVETna"
    "iIqlZ1IaeZXc0Iqmoe9PrFazJZ9590N3kvqeipkPuTCuEc6VvauoTkKvWlw2BSAV6+qszAABnRsA"
    "UlYUv9etUKnWCeZbx1psjk6zPbpPSeYlIue5Kbyswra2ZQWdlXvX6hQfGreEZGWr9KKdlDRkJL/W"
    "iiYnLz+9qwl+HtHlRw6X9t9GxNBUiOoS/SI/0ADxbTQbgko70iy1Quhc2l1a1j1ku0k8xls3DH+s"
    "G4BgVh8seQLKEQdSvbousuDr4m6jKRNuKd6qMae9nWDoIlvHQw1Tdmtq3tLYDYA4WP6NYyTx8PI2"
    "nmJUaZ2Y+YG4+GwPE+n9Va/QwuXYrrIEoSPdQPsGQYim5c/Y1Meu4vycTXzKtTOLGPpmGvYSH6+T"
    "41Eh8GUapCCIpn33yo2GmABNtd9BCU0whFTRytEH3ao/NL4pd7gTuLAp4h2ahVxaGTP/WuSnzbfT"
    "5xzO/OeQmb/IIrs87un4mLlH0aeaG6WFwkMOXWOSgGwSJHGNvbecepo7Fs8wvZA1w+9olgP8sS73"
    "X9bV5TnAMf+3bNKTctpWwxn+SLtM73KV4YEzIPNdMLEaekeuDAJ9cdqToni+SWsKZ8mtY/Dc51AH"
    "1GYr70akROcdSaLCzdCfZMZ3mKlhFxhsIjexKWmMHOvYfIGNUrAajmYxJ8O2C/JNCot5mPjA6IHn"
    "s0zyvpEn8QaM+0bvVhBJimfH4PALGPiVS7Wpc1X3cFEJzVMaZ7FBh+DuOFDumWZeMa8rUdFZOZLt"
    "ApEyx9r8uo0Bs0VTP7bB6S/vyJZSyC6o8sH08sQytnEx34A/N25IbpGbzy9SXYRUdXHUaBNN/urG"
    "ygwDqWKGJ2NrJZJGWKijyWUGeNUqWfaSH6QyMDyzgUhr7j/qmSVdHJ0MI50J9gsKspm4wzjzU2O3"
    "d3jw0iwL1djPF13WrkONPcDW3ka9BGjIFUr0UKQkqc9ASAzhrYmoKdekOxJLMTqgam/nxneLhg/Q"
    "aZhz21TSMC8Qu18gp2y9LgIcQ2aoc6N3v4M2/Yrtv6oalJdc0YDnQE0aAmkShf3a+M7/Hq9kwSxx"
    "5ozLJxcBhNa/lGct/9lY0QdyIpmeL0bCiWDDQqIgARAEqDISzp08MvnOgUCXseGVI8yH7TCSx4cm"
    "vjEe6Oh5os2DoZzW/XzZlvVXL9QiLVXIm1jq8uppnIElwJVJllbmOvYltwqAbpubmxVviyRxafgf"
    "W1SrElJwd99gxC0XsCoCYmVlBYYEGAzuERCbbnqZUsImGC1bX0qVaeGXhlhbh5NPU9tHZdDX4WLh"
    "CfXcft4W5Hylx4rVsHwiTyOpEDe2h8V1xMziIJv/Fcv7bLYOcoyOUDHbeloyq4d2W2OHRJlNa5yc"
    "5HZqu2qilkzVwlItu09txVFqyy5RW3Z+6htFG7FixJacofoaxMDL/mJyI4873a7qKHVqD7cxaKa1"
    "75U1lYy1ITPTgqCG7I+ZArcPjo52T3pf1NmX6+3MsmX5q85Gt9tyZveccUcOw5uqTVgSsnfpD+he"
    "DuFdEE39hSW7UTC2EUTc+RE2Po14B81ywY7apjzYOgFvtmwgduOcKyTKJumFCCiaB3dzyyCsqMHd"
    "hMyqev82OqG847QOHgpcNIn7mcKGtq/Zdl29oRLtoqw/eEqPUu1NbuYJeS815sh4aoBAEoyCH6YY"
    "dgWkCJ3+ozgofP54ChUoJfOANj/nMyO6iws+ZyONlFK/9vQIz6j/UedHpCT1ityry/cu4tm+Lp4A"
    "NegPL4LQS4B2aBMRW+aeB9gFaDgkRkkC3eKc8PwaM4unaKron8MEr93bvs+MVzV6gwek9DkrCVv2"
    "/PqeHEbceYJN3TdbjzrretO8518ph1aU8FmsLEl83oLaszivws5zYg+fgMLKjXI6Sy0viiYqfa2/"
    "/2FxlBmZxLtoFPdyEm7lLAZ+K52g81CewWrqyuMZADzfzNj/RUxhpExa5M9G7gAe7VBoPGhDgad1"
    "tBCe8rMuJjp7IhBqKX9o2q364LxTTDl/ZuMHzCSvyZw/o/dqYZyFXedNU3B2BvQioQd97if7imSV"
    "n3UKnnIKzXoKXSTQnE2lTyRZrzZPKaMCleSOmNCWDN3m+9/8v6jp5VlqdU8x9az0vDYdpsINTijK"
    "DkQSGCMJC/GHGCsTOo2nhx47hr4gRS3qynZJTBv28YRV13Z+yLBKX6XFiSdWYwkUUClwTUpXGaQs"
    "Nh8GweiPyFGuWCinpUIsfblShKdTzotM6JoRJf1rciUXwO8BHnxWz3iN/UzpCr7HKOFSoRoMBSrn"
    "hRSBoEsLLYpM64rkuAuF8DOFzMzHYTWShvGqYz4pDKiAj0xIePXu/8M5YMidn92XhPW5qWQp9cLI"
    "3OHrAq3wubLEzdjB6wl/My2/OcTpGMWsjHH62VP7P4eMrEo2Vjn3yk0mLFE8bx5uAuWkR8UwypPi"
    "nIbiDYk/IYo/0EYznYQB7CNMOINqbFEK7R0oHORPGr/sbp1JNEtKtlkeJ5pIR4Fsk4snfoRPMO4V"
    "M4752e0ERKFTyzyhtIK2+TWlRMMkQid4txo9+dpsnFUMbROnbJatWJ2ug+zCwC6tiW0CCUFBEMly"
    "15xmo4db8ABdg2nXDM6BIPpo3UmNUdWWQ7kiKbGFBnojBV5nGhmQLdHM8zgL5kFkA2nUeE943tay"
    "J5DWhghLjPcqZBdN1CVoBSYNDP+j5WUtCwtiw6zvQ+Oh0TUBDev6a9RE3aEN6s1Lfpq63BRHMEw9"
    "ge5MXbsVV0zJOIVLO9tcQshgmbuU/wqW0/IV/3yRAVYrcS2yystlulxsfZVEw3wxK4mGG6a+ubql"
    "rDRgWLyHhlmCSZ7BtgyV64CnrD+JJ6EPTLHwaDTkQs0syEJfzpXLkyOD2Iivz/0Yj17cWuZ6q3XT"
    "2WqZavXicig1CySvnbiDPnJtzR0s8N42X4/FqYU8K6xhYVbY5s+dE7a4XxPEbntdNo0y+l+btg4n"
    "9sE57JdMETvz5wPyxyIzmpWPsgQZdgeALPm7nleW/aP4qpZ8Y38a7rkkO1RcnNzVuxx//nTswrBo"
    "BJQ97kFBWQgIjbzjBagwq5GTALHTPVdIh2yLeaBgJPGtusN4hknaYr0dTHu13zsy7SXTSA4K/z7P"
    "jQqYyNOjLptcmqXDzBNKA5o0tDeNbWpuGxLEjiVinS/mpO6V76a5oAPVXVDmAPH9KAUQdk2W93Xx"
    "jWTMkpUWkY0UUei6KgrpRJ9R8zoJMq4i1yGyJmEbx6FjOvCEroTJ/WevTnzmiZuLbMVa4SXPBLzo"
    "AXMqvNgJc0272pCTItHxP8r9lYNqxg7T+xJxm5l45UR8bqR8zzlvI9x1n3VSjb/ce7nXO/q8k7AN"
    "R+cgIbsTtCCWsJpH+/Skt3Ioe33sOjWcHx8UOY7xDCEwwTpnNxY9XSXPw+oZhlcMs6pGgNdmldSB"
    "4kAnNH7/SHiFrTtogGxFX6kaASVZqEZ28yNg1VRmGM6rOTtWOlloU1kvuBrHnpXam60a7RTDpCoK"
    "zdhpdbx75y6lv3OOw2y0WnaRLkKeGR491BLPmgweurh2duqxSjyEtJg3RXu7T9ftWuR12pAOUWLc"
    "7cbmihw2iqk184xfrJeGTcC9frQmC8h51DWVOX0YOYXwOr7Bltwby6Mu2/mL8Jq/aNvG9aOoUTpv"
    "e6XGBHkl6RtbDb4Or1UhGaO/rh6NbxpfWxcP19VFwfTUXemOPITh1S/GN183N1k6OtnwX7zc2sjf"
    "FsGQ1dXOgTxMfBhvP/GHgOLnoIPe2BcPXfvmQXj9sG1fsFsd8TaTeJqBYuiTY7pAiOJAU60LRp8u"
    "Rc9WF8j/sUQ+PBjoypdG9yN+oPqr3t7+x7ayAsvT7yOb7vfxlK7Z74/dIOr3TQavIosqvRV5VJ16"
    "qx6IMXGSGUNi1yre0CPcPB4w0vQC1s5vHvvZYRIPgXXuTILeNSZxh89Wu95U5JTSvqesF6QS3KIh"
    "8sj0JhOrMGgQGcHJhTG5Y/4XXfoxLQ=="
)

def _extrair_programa(destino):
    dados = base64.b64decode("".join(_PROG_B64.split()))
    codigo = zlib.decompress(dados)
    with open(destino, "wb") as f:
        f.write(codigo)

# ── Cores ─────────────────────────────────────────────────
C = {
    "fundo":     "#0d1117",
    "fundo2":    "#161b22",
    "painel":    "#21262d",
    "verde":     "#39d353",
    "verde_dim": "#238636",
    "vermelho":  "#f85149",
    "amarelo":   "#e3b341",
    "azul":      "#58a6ff",
    "ciano":     "#79c0ff",
    "texto":     "#f0f6fc",
    "texto_dim": "#8b949e",
}

PACOTES = [
    ("scapy",          "Driver de captura de pacotes Wi-Fi"),
    ("pywifi",         "Scanner aprimorado de redes Wi-Fi"),
    ("comtypes",       "Integração com drivers Windows"),
    ("speedtest-cli",  "Medição de velocidade da internet"),
]

def _tem(lib):
    import importlib.util
    return importlib.util.find_spec(lib) is not None

def _tem_npcap():
    for p in [r"C:\\Windows\\System32\\Npcap",
               r"C:\\Windows\\SysWOW64\\Npcap",
               r"C:\\Program Files\\Npcap"]:
        if os.path.isdir(p):
            return True
    try:
        import winreg
        winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Npcap")
        return True
    except Exception:
        return False

def _is_admin():
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

def _pasta_instalacao():
    base = os.path.join(os.environ.get("LOCALAPPDATA","C:\\Users\\Public"),
                        "RadioProgramador")
    os.makedirs(base, exist_ok=True)
    return base

def _criar_atalho(alvo, nome):
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    lnk     = os.path.join(desktop, f"{nome}.lnk")
    ps = (
        f'$s=(New-Object -COM WScript.Shell).CreateShortcut("{lnk}");'
        f'$s.TargetPath="{PYTHON}";'
        f'$s.Arguments="\"{alvo}\"";'
        f'$s.WorkingDirectory="{os.path.dirname(alvo)}";'
        f'$s.Description="Rádio Programador v{VERSAO}";'
        f'$s.Save()'
    )
    subprocess.run(["powershell","-NoProfile","-Command",ps],
                   capture_output=True, timeout=15)


class Instalador(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Rádio Programador — Instalação")
        self.geometry("620x560")
        self.configure(bg=C["fundo"])
        self.resizable(False, False)
        if SISTEMA == "Windows":
            try:
                import ctypes
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
            except Exception:
                pass
        self._dpi_fix()
        self._tela_boas_vindas()

    def _dpi_fix(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("Verde.Horizontal.TProgressbar",
                    background=C["verde"], troughcolor=C["fundo2"], borderwidth=0)
        s.configure("Azul.Horizontal.TProgressbar",
                    background=C["azul"],  troughcolor=C["fundo2"], borderwidth=0)

    def _limpar(self):
        for w in self.winfo_children():
            w.destroy()

    def _hdr(self, subtitulo=""):
        fr = tk.Frame(self, bg=C["fundo2"], height=72)
        fr.pack(fill="x"); fr.pack_propagate(False)
        tk.Label(fr, text="  RÁDIO PROGRAMADOR",
                 font=("Consolas",19,"bold"),
                 bg=C["fundo2"], fg=C["verde"]).pack(side="left", pady=14)
        if subtitulo:
            tk.Label(fr, text=f"  {subtitulo}",
                     font=("Consolas",9),
                     bg=C["fundo2"], fg=C["texto_dim"]).pack(side="left")
        tk.Label(fr, text=f"v{VERSAO}  ",
                 font=("Consolas",8),
                 bg=C["fundo2"], fg=C["texto_dim"]).pack(side="right")

    def _btn(self, parent, txt, cmd, cor=None, fg="#000", pady=10, state="normal"):
        cor = cor or C["verde"]
        b = tk.Button(parent, text=txt,
                      font=("Consolas",11,"bold"),
                      bg=cor, fg=fg,
                      relief="flat", cursor="hand2",
                      pady=pady, command=cmd, state=state)
        return b

    # ─── TELA 1: Boas-vindas ─────────────────────────────────
    def _tela_boas_vindas(self):
        self._limpar()
        self._hdr()

        corpo = tk.Frame(self, bg=C["fundo"])
        corpo.pack(fill="both", expand=True, padx=40, pady=20)

        tk.Label(corpo,
                 text="Bem-vindo ao instalador",
                 font=("Consolas",14,"bold"),
                 bg=C["fundo"], fg=C["amarelo"]).pack(anchor="w")

        tk.Label(corpo,
                 text="Ferramenta profissional de análise de redes Wi-Fi.",
                 font=("Consolas",10),
                 bg=C["fundo"], fg=C["texto_dim"]).pack(anchor="w", pady=(2,16))

        # O que vai ser instalado
        fr = tk.Frame(corpo, bg=C["painel"], padx=20, pady=14)
        fr.pack(fill="x", pady=(0,12))

        tk.Label(fr, text="O que será instalado:",
                 font=("Consolas",9,"bold"),
                 bg=C["painel"], fg=C["verde"]).pack(anchor="w", pady=(0,6))

        itens = [
            ("📡", "Scanner de redes Wi-Fi ao redor"),
            ("🔍", "Análise de senha WPA2 com wordlist"),
            ("📶", "Captura de handshake real (requer adaptador compatível)"),
            ("💻", "Visualização de dispositivos na rede"),
            ("⚡", "Teste de velocidade da internet"),
            ("⛔", "Desconexão de clientes (Deauth)"),
        ]
        for icone, desc in itens:
            f = tk.Frame(fr, bg=C["painel"])
            f.pack(fill="x", pady=2)
            tk.Label(f, text=icone, font=("Consolas",11),
                     bg=C["painel"], fg=C["verde"], width=3).pack(side="left")
            tk.Label(f, text=desc, font=("Consolas",9),
                     bg=C["painel"], fg=C["texto"]).pack(side="left")

        # Aviso legal
        av = tk.Frame(corpo, bg="#1a1000", pady=8)
        av.pack(fill="x", pady=(0,16))
        tk.Label(av,
                 text="  ⚠  Use somente em redes próprias ou com autorização formal.",
                 font=("Consolas",8,"bold"),
                 bg="#1a1000", fg=C["amarelo"], anchor="w").pack(fill="x", padx=12)

        fr_btn = tk.Frame(corpo, bg=C["fundo"])
        fr_btn.pack(fill="x")

        self._btn(fr_btn, "INSTALAR AGORA  →",
                  self._tela_instalando,
                  C["verde"], "#000", 12).pack(fill="x", pady=(0,6))
        self._btn(fr_btn, "Cancelar",
                  self.destroy,
                  C["fundo2"], C["texto_dim"], 6).pack(fill="x")

    # ─── TELA 2: Instalando ──────────────────────────────────
    def _tela_instalando(self):
        self._limpar()
        self._hdr("Instalando componentes...")

        self.corpo = tk.Frame(self, bg=C["fundo"])
        self.corpo.pack(fill="both", expand=True, padx=32, pady=16)

        # Passos visuais
        self.passos_frame = tk.Frame(self.corpo, bg=C["fundo"])
        self.passos_frame.pack(fill="x", pady=(0,12))

        nomes_passos = [
            "Preparando instalação",
            "Instalando componentes Python",
            "Verificando driver Npcap",
            "Configurando o programa",
            "Criando atalho na área de trabalho",
        ]
        self.lbl_passos = []
        for i, nome in enumerate(nomes_passos):
            f = tk.Frame(self.passos_frame, bg=C["fundo"])
            f.pack(fill="x", pady=2)
            ic = tk.Label(f, text="○", font=("Consolas",12),
                          bg=C["fundo"], fg=C["texto_dim"], width=3)
            ic.pack(side="left")
            lb = tk.Label(f, text=nome, font=("Consolas",9),
                          bg=C["fundo"], fg=C["texto_dim"])
            lb.pack(side="left")
            self.lbl_passos.append((ic, lb))

        # Barra de progresso
        self.barra = ttk.Progressbar(self.corpo,
                                      style="Verde.Horizontal.TProgressbar",
                                      mode="determinate", length=540)
        self.barra.pack(fill="x", pady=(8,4))

        self.lbl_status = tk.Label(self.corpo, text="Iniciando...",
                                    font=("Consolas",8),
                                    bg=C["fundo"], fg=C["texto_dim"])
        self.lbl_status.pack(anchor="w")

        # Log compacto
        self.log_txt = tk.Text(self.corpo, height=7,
                                font=("Consolas",8),
                                bg=C["painel"], fg=C["verde"],
                                relief="flat", state="disabled",
                                wrap="word")
        self.log_txt.pack(fill="both", expand=True, pady=(8,0))
        self.log_txt.tag_config("ok",    foreground=C["verde"])
        self.log_txt.tag_config("aviso", foreground=C["amarelo"])
        self.log_txt.tag_config("erro",  foreground=C["vermelho"])
        self.log_txt.tag_config("info",  foreground=C["azul"])
        self.log_txt.tag_config("dim",   foreground=C["texto_dim"])

        threading.Thread(target=self._instalar, daemon=True).start()

    def _log(self, msg, tag="dim"):
        def _do():
            self.log_txt.config(state="normal")
            self.log_txt.insert("end", msg+"\n", tag)
            self.log_txt.see("end")
            self.log_txt.config(state="disabled")
        self.after(0, _do)

    def _passo(self, idx, status="ok"):
        def _do():
            ic, lb = self.lbl_passos[idx]
            if status == "ok":
                ic.config(text="✓", fg=C["verde"])
                lb.config(fg=C["verde"])
            elif status == "ativo":
                ic.config(text="►", fg=C["amarelo"])
                lb.config(fg=C["amarelo"])
            elif status == "aviso":
                ic.config(text="!", fg=C["amarelo"])
                lb.config(fg=C["amarelo"])
            elif status == "erro":
                ic.config(text="✗", fg=C["vermelho"])
                lb.config(fg=C["vermelho"])
        self.after(0, _do)

    def _upd(self, pct, msg=""):
        def _do():
            self.barra["value"] = pct
            if msg:
                self.lbl_status.config(text=msg)
        self.after(0, _do)

    def _instalar(self):
        import time

        # PASSO 0: Preparar
        self._passo(0, "ativo")
        self._upd(5, "Preparando pasta de instalação...")
        self._log("Iniciando instalação do Rádio Programador v5.0", "info")
        self._log(f"Python: {sys.version_info.major}.{sys.version_info.minor} "
                  f"({'64' if sys.maxsize>2**32 else '32'}-bit)", "dim")

        pasta = _pasta_instalacao()
        self._log(f"Pasta: {pasta}", "dim")
        self._passo(0, "ok")
        self._upd(10, "")
        time.sleep(0.3)

        # PASSO 1: Pacotes Python
        self._passo(1, "ativo")
        self._upd(15, "Atualizando pip...")
        try:
            subprocess.run([PYTHON,"-m","pip","install","--upgrade","pip","--quiet"],
                           capture_output=True, timeout=30)
            self._log("pip atualizado.", "ok")
        except Exception:
            pass

        total = len(PACOTES)
        ok_count = 0
        for i,(pkg,desc) in enumerate(PACOTES):
            pct = 15 + int((i/total)*35)
            self._upd(pct, f"Instalando: {desc}...")
            self._log(f"Instalando {desc} ({pkg})...", "dim")
            try:
                subprocess.check_call(
                    [PYTHON,"-m","pip","install",pkg,"--upgrade","--quiet"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=90
                )
                self._log(f"  ✓ {pkg} instalado.", "ok")
                ok_count += 1
            except Exception as e:
                self._log(f"  ! {pkg}: {e}", "aviso")
            time.sleep(0.2)

        if ok_count >= 2:
            self._passo(1, "ok")
        else:
            self._passo(1, "aviso")
        self._upd(52, "")
        time.sleep(0.3)

        # PASSO 2: Npcap
        self._passo(2, "ativo")
        self._upd(55, "Verificando driver Npcap...")
        time.sleep(0.5)
        if _tem_npcap():
            self._log("Npcap já está instalado!", "ok")
            self._passo(2, "ok")
        else:
            self._log("Npcap não encontrado.", "aviso")
            self._log("O programa funciona sem ele, mas captura avançada requer Npcap.", "aviso")
            self._passo(2, "aviso")
            # Agenda tela de Npcap após instalação
            self._npcap_pendente = True
        self._upd(60, "")
        time.sleep(0.3)

        # PASSO 3: Extrair programa
        self._passo(3, "ativo")
        self._upd(65, "Instalando programa principal...")
        prog_path = os.path.join(pasta, "radio_programador.py")
        try:
            _extrair_programa(prog_path)
            self._log(f"Programa instalado em: {prog_path}", "ok")
            self._passo(3, "ok")
        except Exception as e:
            self._log(f"Erro ao extrair programa: {e}", "erro")
            self._passo(3, "erro")
        self._upd(80, "")
        time.sleep(0.3)

        # PASSO 4: Atalho
        self._passo(4, "ativo")
        self._upd(85, "Criando atalho na área de trabalho...")
        try:
            _criar_atalho(prog_path, "Rádio Programador")
            self._log("Atalho criado na área de trabalho.", "ok")
            self._passo(4, "ok")
        except Exception as e:
            self._log(f"Atalho não criado: {e}", "aviso")
            self._passo(4, "aviso")

        self._upd(100, "Instalação concluída!")
        time.sleep(0.5)
        self._prog_path = prog_path
        self.after(0, self._tela_concluida)

    # ─── TELA 3: Concluída ───────────────────────────────────
    def _tela_concluida(self):
        self._limpar()
        self._hdr()

        corpo = tk.Frame(self, bg=C["fundo"])
        corpo.pack(fill="both", expand=True, padx=40, pady=20)

        tk.Label(corpo, text="✓  Instalação Concluída!",
                 font=("Consolas",16,"bold"),
                 bg=C["fundo"], fg=C["verde"]).pack(anchor="w")

        tk.Label(corpo,
                 text="O Rádio Programador foi instalado com sucesso.",
                 font=("Consolas",10),
                 bg=C["fundo"], fg=C["texto_dim"]).pack(anchor="w", pady=(2,14))

        # Status dos componentes
        fr = tk.Frame(corpo, bg=C["painel"], padx=20, pady=14)
        fr.pack(fill="x", pady=(0,12))

        tk.Label(fr, text="Status dos componentes:",
                 font=("Consolas",9,"bold"),
                 bg=C["painel"], fg=C["verde"]).pack(anchor="w", pady=(0,6))

        def linha(txt, ok, aviso=False):
            f = tk.Frame(fr, bg=C["painel"])
            f.pack(fill="x", pady=2)
            if ok:
                ic, cor = "✓", C["verde"]
            elif aviso:
                ic, cor = "!", C["amarelo"]
            else:
                ic, cor = "✗", C["vermelho"]
            tk.Label(f, text=ic, font=("Consolas",10,"bold"),
                     bg=C["painel"], fg=cor, width=3).pack(side="left")
            tk.Label(f, text=txt, font=("Consolas",9),
                     bg=C["painel"], fg=C["texto"]).pack(side="left")

        linha(f"Python {'64' if sys.maxsize>2**32 else '32'}-bit", True)
        linha("scapy (captura de pacotes)", _tem("scapy"), not _tem("scapy"))
        linha("pywifi (scanner de redes)",  _tem("pywifi"),  not _tem("pywifi"))
        linha("speedtest-cli (velocidade)", _tem("speedtest"), not _tem("speedtest"))

        if not _tem_npcap():
            # Bloco de instalação do Npcap
            av = tk.Frame(corpo, bg="#1a0d00", padx=16, pady=12)
            av.pack(fill="x", pady=(0,10))
            tk.Label(av,
                     text="⚠  Npcap não está instalado",
                     font=("Consolas",10,"bold"),
                     bg="#1a0d00", fg=C["amarelo"]).pack(anchor="w")
            tk.Label(av,
                     text=(
                         "Para captura de handshake e envio de pacotes,\n"
                         "instale o Npcap (gratuito, leva ~1 minuto).\n"
                         "Marque: 'WinPcap API compatibility' e 'Support raw 802.11 traffic'"
                     ),
                     font=("Consolas",8),
                     bg="#1a0d00", fg=C["texto_dim"],
                     justify="left").pack(anchor="w", pady=(4,8))
            self._btn(av, "Baixar e instalar o Npcap (gratuito)",
                      lambda: webbrowser.open("https://npcap.com/#download"),
                      "#2d1800", C["amarelo"], 7).pack(fill="x")
        else:
            linha("Npcap (driver de pacotes)", True)

        fr_btn = tk.Frame(corpo, bg=C["fundo"])
        fr_btn.pack(fill="x", pady=(10,0))

        self._btn(fr_btn, "🚀  ABRIR O PROGRAMA",
                  self._abrir_programa,
                  C["verde"], "#000", 12).pack(fill="x", pady=(0,6))

        self._btn(fr_btn, "Fechar instalador",
                  self.destroy,
                  C["fundo2"], C["texto_dim"], 6).pack(fill="x")

    def _abrir_programa(self):
        prog = getattr(self, "_prog_path", None)
        if prog and os.path.exists(prog):
            if SISTEMA == "Windows":
                try:
                    import ctypes
                    ret = ctypes.windll.shell32.ShellExecuteW(
                        None, "runas", PYTHON, f'"{prog}"', None, 1)
                    if ret <= 32:
                        subprocess.Popen([PYTHON, prog])
                except Exception:
                    subprocess.Popen([PYTHON, prog])
            else:
                subprocess.Popen([PYTHON, prog])
        self.destroy()


if __name__ == "__main__":
    app = Instalador()
    app.mainloop()
